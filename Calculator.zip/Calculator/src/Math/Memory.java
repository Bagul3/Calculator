package Math;

public class Memory {

	private float memory = 0;
	
	public float getMemory(){
		return memory;
	}
	
	public void setMemory(float value){
		memory = value;
	}
	
}
